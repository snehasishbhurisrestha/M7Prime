<div class="section-body">
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    Copyright © 2025 <a href="javascript:void(0)">{{ config('app.name', 'Laravel') }}</a>. 
                    Crafted with <i class="fa fa-heart text-danger"></i>
                    by <a href="https://codeofdolphins.com/"><b>Code of Dolphins</b></a>
                </div>
                {{-- <div class="col-md-6 col-sm-12 text-md-right">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="../doc/javascript:void(0)">Documentation</a></li>
                        <li class="list-inline-item"><a href="javascript:void(0)">FAQ</a></li>
                    </ul>
                </div> --}}
            </div>
        </div>
    </footer>
</div>