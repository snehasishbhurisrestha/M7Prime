<div class="section-body" id="page_top">
    <div class="container-fluid">
        <div class="page-header">
            <div class="left">                        
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="What you want to find">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button">Search</button>
                    </div>
                </div>
            </div>
            <div class="right">
                {{-- <ul class="nav nav-pills">                            
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Pages</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="page-empty.html">Empty page</a>
                            <a class="dropdown-item" href="page-profile.html">Profile</a>
                            <a class="dropdown-item" href="page-search.html">Search Results</a>
                            <a class="dropdown-item" href="page-timeline.html">Timeline</a>
                            <a class="dropdown-item" href="page-invoices.html">Invoices</a>
                            <a class="dropdown-item" href="page-pricing.html">Pricing</a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Auth</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="login.html">Login</a>
                            <a class="dropdown-item" href="register.html">Register</a>
                            <a class="dropdown-item" href="forgot-password.html">Forgot password</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="404.html">404 error</a>
                            <a class="dropdown-item" href="500.html">500 error</a>
                        </div>
                    </li>
                </ul> --}}
                <div class="notification d-flex">
                    {{-- <div class="dropdown d-flex">
                        <a class="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-1" data-toggle="dropdown"><i class="fa fa-language"></i></a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="#"><img class="w20 mr-2" src="../assets/images/flags/us.svg" alt="">English</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#"><img class="w20 mr-2" src="../assets/images/flags/es.svg" alt="">Spanish</a>
                            <a class="dropdown-item" href="#"><img class="w20 mr-2" src="../assets/images/flags/jp.svg" alt="">japanese</a>
                            <a class="dropdown-item" href="#"><img class="w20 mr-2" src="../assets/images/flags/bl.svg" alt="">France</a> 
                        </div>
                    </div> --}}
                    {{-- <div class="dropdown d-flex">
                        <a class="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-1" data-toggle="dropdown"><i class="fa fa-envelope"></i><span class="badge badge-success nav-unread"></span></a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <ul class="right_chat list-unstyled w350 p-0">
                                <li class="online">
                                    <a href="javascript:void(0);" class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar4.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Donald Gardner</span>
                                            <div class="message">It is a long established fact that a reader</div>
                                            <small>11 mins ago</small>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </a>
                                </li>
                                <li class="online">
                                    <a href="javascript:void(0);" class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar5.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Wendy Keen</span>
                                            <div class="message">There are many variations of passages of Lorem Ipsum</div>
                                            <small>18 mins ago</small>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </a>                            
                                </li>
                                <li class="offline">
                                    <a href="javascript:void(0);" class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar2.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Matt Rosales</span>
                                            <div class="message">Contrary to popular belief, Lorem Ipsum is not simply</div>
                                            <small>27 mins ago</small>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </a>                            
                                </li>
                                <li class="online">
                                    <a href="javascript:void(0);" class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar3.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Phillip Smith</span>
                                            <div class="message">It has roots in a piece of classical Latin literature from 45 BC</div>
                                            <small>33 mins ago</small>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </a>                            
                                </li>                        
                            </ul>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0)" class="dropdown-item text-center text-muted-dark readall">Mark all as read</a>
                        </div>
                    </div> --}}
                    {{-- <div class="dropdown d-flex">
                        <a class="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-1" data-toggle="dropdown"><i class="fa fa-bell"></i><span class="badge badge-primary nav-unread"></span></a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <ul class="list-unstyled feeds_widget">
                                <li>
                                    <div class="feeds-left">
                                        <span class="avatar avatar-blue"><i class="fa fa-check"></i></span>
                                    </div>
                                    <div class="feeds-body ml-3">
                                        <p class="text-muted mb-0">Campaign <strong class="text-blue font-weight-bold">Holiday</strong> is nearly reach budget limit.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="feeds-left">
                                        <span class="avatar avatar-green"><i class="fa fa-user"></i></span>
                                    </div>
                                    <div class="feeds-body ml-3">
                                        <p class="text-muted mb-0">New admission <strong class="text-green font-weight-bold">32</strong> in computer department.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="feeds-left">
                                        <span class="avatar avatar-red"><i class="fa fa-info"></i></span>
                                    </div>
                                    <div class="feeds-body ml-3">
                                        <p class="text-muted mb-0">6th sem result <strong class="text-red font-weight-bold">67%</strong> in computer department.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="feeds-left">
                                        <span class="avatar avatar-azure"><i class="fa fa-thumbs-o-up"></i></span>
                                    </div>
                                    <div class="feeds-body ml-3">
                                        <p class="text-muted mb-0">New Feedback <strong class="text-azure font-weight-bold">53</strong> for university assessment.</p>
                                    </div>
                                </li>
                            </ul>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0)" class="dropdown-item text-center text-muted-dark readall">Mark all as read</a>
                        </div>
                    </div> --}}
                    <div class="dropdown d-flex">
                        <a href="javascript:void(0)" class="chip ml-3" data-toggle="dropdown">
                            <span class="avatar" style="background-image: url({{ asset('assets/admin-assets/images/xs/avatar5.png') }})"></span> {{ Auth::user()->name }}</a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="{{ route('profile.edit') }}"><i class="dropdown-icon fe fe-user"></i> Profile</a>
                            {{-- <a class="dropdown-item" href="app-setting.html"><i class="dropdown-icon fe fe-settings"></i> Settings</a> --}}
                            {{-- <a class="dropdown-item" href="app-email.html"><span class="float-right"><span class="badge badge-primary">6</span></span><i class="dropdown-icon fe fe-mail"></i> Inbox</a> --}}
                            {{-- <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon fe fe-send"></i> Message</a> --}}
                            <div class="dropdown-divider"></div>
                            {{-- <a class="dropdown-item" href="javascript:void(0)"><i class="dropdown-icon fe fe-help-circle"></i> Need help?</a> --}}
                            <form method="POST" action="{{ route('logout') }}" style="display: inline;">
                                @csrf
                                <a class="dropdown-item" href="{{ route('logout') }}" 
                                    onclick="event.preventDefault(); this.closest('form').submit();">
                                    <i class="dropdown-icon fe fe-log-out"></i> Sign out
                                </a>
                            </form>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>